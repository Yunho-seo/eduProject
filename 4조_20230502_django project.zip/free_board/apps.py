from django.apps import AppConfig


class FreeboardConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "free_board"
