from django.contrib import admin
from .models import Free_Board

admin.site.register(Free_Board)