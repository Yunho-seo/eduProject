from django.contrib import admin
from .models import Certification

admin.site.register(Certification)