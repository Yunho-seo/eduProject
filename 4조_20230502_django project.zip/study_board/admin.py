from django.contrib import admin
from .models import Study_Board

admin.site.register(Study_Board)