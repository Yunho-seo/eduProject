from django.contrib import admin
from .models import study

admin.site.register(study)