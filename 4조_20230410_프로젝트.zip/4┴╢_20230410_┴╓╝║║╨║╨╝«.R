bike <- read.csv("temp.csv",header=T,encoding="UTF_8")
str(bike)
sum(is.na(bike))
class(bike)
pro_bike <- prcomp(bike[,-c(1,4)], scale = T)
str(pro_bike)
plot(pro_bike,type="lines")
names(pro_bike)
summary(prcomp(bike[,-c(1,4)],scale. = T))
pro_bike$rotation
pro_bike$sdev
pro_bike$center
bike.prin <- princomp(bike[,-c(1,4)],cor=T)
bike.prin
screeplot(bike.prin,npcs=2,type="lines")

#주성분 분석(비와 자전거 대여량)
rain <- read.csv("rain.csv",header=T,encoding="UTF_8")
str(rain)
sum(is.na(rain))
class(rain)
pro_rain <- prcomp(rain)
                        
plot(pro_rain,type="lines")
names(pro_rain)
summary(prcomp(rain[,-c(1,4)],scale. = T))
pro_rain$rotation
pro_rain$sdev
pro_rain$center
bike.prin <- princomp(rain[,-c(1,4)],cor=T)
bike.prin
screeplot(bike.prin,npcs=2,type="lines")