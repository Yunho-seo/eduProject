data <- read.csv("22년도 용산구 데이터 (지하철추가).csv", header = T, fileEncoding = "CP949")

str(data)
head(data)
class(data)
summary(data)

data <- data[-1]
(data_sc <- scale(data[-4]))    # 정규화
(data_df <- data.frame(data_sc))
data_df$holiday <- data$holiday
head(data_df)
str(data_df)
class(data_df)
dim(data_df)

# 지하철 이용량과 온도,강수량의 회귀분석

subway_lm <- lm(subway ~ temp + rain, data = data_df)
summary(subway_lm)
cor(data_df$temp, data_df$subway) # 0.2306602
cor(data_df$rain, data_df$subway) # -0.05523789

# F검정 통계량 : p-value : 5.068e-06 # p < 0.05 : 대립가설 : 유의미
# t검정 통계량 : 0.0322 # p < 0.05 : 대립가설 : 무의미
# 모형의 설명력 : Adjusted R-squared: 0.05998

dwtest(subway_lm)   # 독립성 확인(0~4, 2에 가까울 수록 상관성 x) : DW = 1.2813
vif(subway_lm)      # 자기상관성 확인  temp : 1.052022  rain : 1.052022   # 값이 10이상일 경우 다중 공선성이 있다고 볼 수 있음
bptest(subway_lm)   # 등분산성 확인 : p-value = 0.08741 : 귀무가설 : 등분산O

# 시각화
library(ggplot2)
ggplot(subway_lm, aes(x = temp, y = subway)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)

ggplot(subway_lm, aes(x = rain, y = subway)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)

### 버스 이용량과 온도,강수량의 회귀분석

bus_lm <- lm(bus ~ temp + rain, data = data_df)
summary(bus_lm)
cor(data_df$temp, data_df$bus) #  0.3339601
cor(data_df$rain, data_df$bus) # -0.02853196

# F검정 통계량 : p-value : 5.184e-11 # p < 0.05 : 대립가설 : 유의미
# t검정 통계량 : 0.0329 # p < 0.05 : 대립가설 : 무의미
# 모형의 설명력 : Adjusted R-squared: 0.1178

dwtest(bus_lm)   # 독립성 확인(0~4, 2에 가까울 수록 상관성 x) : DW = 1.2216
vif(bus_lm)      # 자기상관성 확인  temp : 1.052022   rain : 1.052022  # 값이 10이상일 경우 다중 공선성이 있다고 볼 수 있음
bptest(bus_lm)   # 등분산성 확인 : p-value = 0.007368 : 대립가설 : 등분산x

# 시각화
library(ggplot2)
ggplot(bus_lm, aes(x = temp, y = bus)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)

ggplot(bus_lm, aes(x = rain, y = bus)) +
  geom_point() +
  geom_smooth(method = "lm", se = FALSE)